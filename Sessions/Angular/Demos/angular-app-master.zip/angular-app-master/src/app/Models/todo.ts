export interface IToDoItem{
    id:number;
    text:string;
    isDone:boolean;
}