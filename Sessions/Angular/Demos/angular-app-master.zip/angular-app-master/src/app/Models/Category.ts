export interface ICategory{
    id: number,
    name:string,
    desciption: string
}