import { Component, OnInit } from '@angular/core';
// import { ProductListComponent } from '../product-list/product-list.component';
// import { IProduct } from '../../../Models/Product';
// import { ProductService } from '../../../Services/product.service';

@Component({
  selector: 'app-productbyId',
  templateUrl: './productbyId.component.html',
  styleUrls: ['./productbyId.component.css'],
})
export class ProductbyIdComponent implements OnInit {
  ngOnInit() {}
}
