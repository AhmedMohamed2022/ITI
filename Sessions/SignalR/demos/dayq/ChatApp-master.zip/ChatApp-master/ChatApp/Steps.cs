﻿/*
 1) Create MyHub (manage Connect client) [ more than one hub (Scop | Connected Client)]
    //separate of concern (single responsiblity)
 2) HttpRequest Piple Line  "add Middleware URL ==> Hub"
 3) Service AddSignalR();
 */