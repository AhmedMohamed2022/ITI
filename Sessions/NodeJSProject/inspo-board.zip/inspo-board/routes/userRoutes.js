const express = require("express");
const router = express.Router();
const quoteController = require("../controllers/quoteController"); // ✅ ADD THIS LINE

router.get("/public", async (req, res) => {
  try {
    const quotes = await quoteController.getAllQuotes();
    res.json(quotes);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
