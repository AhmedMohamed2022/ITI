﻿namespace EF_Core.Enums
{
    public enum TypeOfPayment
    {
        Cash,
        Paypal,
        Stribe
    }
}