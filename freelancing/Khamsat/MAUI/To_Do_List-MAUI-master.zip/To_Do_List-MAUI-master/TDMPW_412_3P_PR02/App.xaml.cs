﻿namespace TDMPW_412_3P_PR02;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new MainPage();
	}
}
