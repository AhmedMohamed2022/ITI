﻿namespace TDMPW_412_3P_PR02;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
