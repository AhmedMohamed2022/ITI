﻿namespace Marvelous.Core.Interfaces.ViewModels
{
    public interface IParameters
    {
    }
}
