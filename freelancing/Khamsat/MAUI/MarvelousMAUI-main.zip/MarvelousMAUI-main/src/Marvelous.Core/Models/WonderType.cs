﻿namespace Marvelous.Core.Models
{
    public enum WonderType
    {
        ChichenItza,
        ChristRedeemer,
        Colosseum,
        GreatWall,
        MachuPicchu,
        Petra,
        PyramidsGiza,
        TajMahal,
    }
}
