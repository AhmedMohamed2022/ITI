﻿namespace Marvelous.Core.Models
{
    public class TimelineEvent
    {
        public int Year { get; init; }
        public string DescriptionKey { get; init; }
    }
}
