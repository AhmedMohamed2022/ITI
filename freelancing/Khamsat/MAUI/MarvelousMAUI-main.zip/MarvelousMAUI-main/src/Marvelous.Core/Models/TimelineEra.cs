﻿namespace Marvelous.Core.Models
{
    public class TimelineEra
    {
        public string TitleKey { get; set; }
        public int StartYear { get; set; }
        public int EndYear { get; set; }
    }
}
