# Copyright notice

**Visual assets are copyrighted** and **used with permission**. Please visit the [Wonderous GitHub repository](https://github.com/gskinnerTeam/flutter-wonderous-app) for original version of the assets.