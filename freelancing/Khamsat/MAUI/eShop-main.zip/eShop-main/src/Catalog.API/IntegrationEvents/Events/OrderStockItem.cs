﻿namespace eShop.Catalog.API.IntegrationEvents.Events;

public record OrderStockItem(int ProductId, int Units);
