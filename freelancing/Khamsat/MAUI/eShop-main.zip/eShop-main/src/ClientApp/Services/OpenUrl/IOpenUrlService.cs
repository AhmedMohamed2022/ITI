﻿namespace eShop.ClientApp.Services.OpenUrl;

public interface IOpenUrlService
{
    Task OpenUrl(string url);
}
