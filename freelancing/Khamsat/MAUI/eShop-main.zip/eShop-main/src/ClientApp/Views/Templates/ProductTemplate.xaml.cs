﻿namespace eShop.ClientApp.Views.Templates;

public partial class ProductTemplate : ContentView
{
    public ProductTemplate()
    {
        InitializeComponent();
    }
}
