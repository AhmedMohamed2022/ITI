﻿namespace eShop.ClientApp;

public static class AppActions
{
    public static readonly AppAction
        ViewProfileAction = new("view_profile", "View Profile", "View your user profile");
}
