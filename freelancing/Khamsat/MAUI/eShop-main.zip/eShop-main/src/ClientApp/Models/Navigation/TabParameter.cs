﻿namespace eShop.ClientApp.Models.Navigation;

public class TabParameter
{
    public int TabIndex { get; set; }
}
