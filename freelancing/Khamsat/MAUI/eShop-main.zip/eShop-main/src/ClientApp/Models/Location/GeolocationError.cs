﻿namespace eShop.ClientApp.Models.Location;

public enum GeolocationError
{
    PositionUnavailable,
    Unauthorized
}
