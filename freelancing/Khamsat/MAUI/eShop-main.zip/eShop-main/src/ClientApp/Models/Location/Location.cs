﻿namespace eShop.ClientApp.Models.Location;

public class Location
{
    public double Longitude { get; set; }
    public double Latitude { get; set; }
}
