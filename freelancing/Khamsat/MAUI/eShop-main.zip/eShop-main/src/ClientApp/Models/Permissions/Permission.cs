﻿namespace eShop.ClientApp.Models.Permissions;

public enum Permission
{
    Unknown,
    Location,
    LocationAlways,
    LocationWhenInUse
}
