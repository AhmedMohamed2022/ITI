﻿namespace eShop.ClientApp.Models.Orders;

public class CardType
{
    public int Id { get; set; }
    public string Name { get; set; }
}
