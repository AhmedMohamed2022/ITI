﻿namespace eShop.ClientApp.Effects;

public class EntryLineColorEffect : RoutingEffect
{
    public EntryLineColorEffect()
        : base("ClientApp.EntryLineColorEffect")
    {
    }
}
