﻿namespace eShop.OrderProcessor;

public class BackgroundTaskOptions
{
    public int GracePeriodTime { get; set; }

    public int CheckUpdateTime { get; set; }
}
