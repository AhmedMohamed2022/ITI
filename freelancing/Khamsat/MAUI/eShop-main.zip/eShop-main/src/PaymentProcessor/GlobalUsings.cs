﻿global using eShop.EventBus.Abstractions;
global using eShop.EventBus.Events;
global using eShop.PaymentProcessor;
global using eShop.PaymentProcessor.IntegrationEvents.EventHandling;
global using eShop.PaymentProcessor.IntegrationEvents.Events;
global using Microsoft.Extensions.Options;
global using eShop.ServiceDefaults;
