﻿global using System.ComponentModel.DataAnnotations.Schema;
global using System.Data.Common;
global using System.Reflection;
global using System.Text.Json;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;
global using Microsoft.EntityFrameworkCore.Storage;
global using eShop.EventBus.Events;
