﻿global using eShop.ServiceDefaults;
