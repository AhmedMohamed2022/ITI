﻿global using System.Reflection;
global using eShop.Ordering.Domain.Exceptions;
global using MediatR;
global using eShop.Ordering.Domain.AggregatesModel.BuyerAggregate;
global using eShop.Ordering.Domain.AggregatesModel.OrderAggregate;
global using eShop.Ordering.Domain.Events;
global using eShop.Ordering.Domain.Seedwork;
